from django.contrib import admin
from .models import Class_Master
from .models import Class_Member
# Register your models here.

admin.site.register(Class_Master)
admin.site.register(Class_Member)