/login/

post - Login Details
[{ 	USERNAME : Siddharth,
	PASSWORD : Helloworld
}]

get - User Details
[{ 	Name : Siddharth,
	Sname : Chauhan,
	Address : A/4 Achal Residency Part-2,
	Phone : 9687222106
	Age : 20,
	DOB : 17/03/1996
}]

if error = 202:
	print ("Status Accepted")
else if errorr = 404:
	printt ("No data found or code error")
