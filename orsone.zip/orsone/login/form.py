from django import forms
from login.models import Member_Details


class RegisterForm(forms. ModelForm):
    password = forms.CharField(widget=forms.PasswordInput)

    fname = forms.CharField(max_length=20)
    mname = forms.CharField(max_length=20)
    lname = forms.CharField(max_length=20)
    gender = forms.CharField(max_length=10)
    usertype = forms.CharField(max_length=20)
    email = forms.CharField(max_length=20)
    address = forms.CharField(max_length=100)
    contact = forms.IntegerField()
    state = forms.CharField(max_length=20)
    city = forms.CharField(max_length=20)
    qualification = forms.CharField(max_length=50)
    resume = forms.FileField()
    joindate = forms.DateField()

    class Meta:
       model = Member_Details
       fields = ('fname', 'mname', 'lname', 'email', 'password', 'address', 'contact', 'gender', 'usertype','state','city','qualification','resume','joindate')
