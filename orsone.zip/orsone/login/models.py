from __future__ import unicode_literals

from django.db import models


# Create your models here.
class Admin_login(models.Model):
    Admin_Id = models.IntegerField(primary_key=True, null=False)
    User_name = models.CharField(max_length=20, null=False)
    Password = models.CharField(max_length=20, null=False)
    Email = models.CharField(max_length=20, null=False)

    def __unicode__(self):
        return str(self.User_name)

class State_Master(models.Model):
    State_id = models.IntegerField(primary_key=True, null=False)
    Statename = models.CharField(max_length=20, null=False)

    def __unicode__(self):
        return str(self.Statename)

class City_Master(models.Model):
    City_id = models.IntegerField(primary_key=True, null=False)
    Cityname = models.CharField(max_length=20, null=False)
    State_id = models.ForeignKey(State_Master)

    def __unicode__(self):
        return str(self.Cityname)


class Member_Details(models.Model):
    member_id = models.IntegerField(primary_key=True)
    fname = models.CharField(max_length=20, null=False)
    mname = models.CharField(max_length=20, null=False)
    lname = models.CharField(max_length=20, null=False)
    gender = models.CharField(max_length=10, choices=(('male', 'Male'), ('female', 'Female')))
    usertype = models.CharField(max_length=20, choices=(('member', 'Member'), ('instructor', 'Instructor'),('admin','Admin')))
    email = models.CharField(max_length=20, null=False)
    password = models.CharField(max_length=20, null=False)
    address = models.CharField(max_length=100, null=False)
    state = models.CharField(max_length= 20, null=True)
    city = models.CharField(max_length= 20, null=True)
    contact = models.IntegerField(null=False)
    qualification = models.CharField(max_length=50, null=True)
    resume = models.FileField(null=True)
    joindate = models.DateField(null= True)

    def __unicode__(self):
        return str(self.fname)