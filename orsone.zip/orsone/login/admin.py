from django.contrib import admin

from .models import Admin_login
from .models import Member_Details
from .models import State_Master
from .models import City_Master

# Register your models here.
admin.site.register(Admin_login)
admin.site.register(Member_Details)
admin.site.register(State_Master)
admin.site.register(City_Master)