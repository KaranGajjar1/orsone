from django.shortcuts import redirect, render
from .form import RegisterForm
from models import Member_Details
from course.models import Course_Master, Member_Course
from django.http import HttpResponse
from django.core import serializers
import json


def home(request):
    return render(request, 'index.html')

def dash(request):
    return  render(request,'home.html')

def registerform(request):
    return render(request, 'register.html')

def auth(request):
    return render(request, 'login.html')

def viewprofile(request):
    #queryset = Member_Details.objects.all().value()
    #return render(request, 'profile.html', {'details':queryset})
    return render(request, 'profile.html',)


def memberdata(request):
    queryset = Member_Details.objects.all().filter(usertype = 'member')
    return HttpResponse(serializers.serialize("json", queryset), content_type='application/json')
def instructordata(request):
    queryset = Member_Details.objects.all().filter(usertype = 'instructor')
    return HttpResponse(serializers.serialize("json", queryset), content_type='application/json')


def Registerdata(request):
    if request.method == 'POST':
        fname = request.POST.get('fname')
        mname = request.POST.get('mname')
        lname = request.POST.get('lname')
        email = request.POST.get('email')
        password = request.POST.get('password')
        address = request.POST.get('address')
        contact = request.POST.get('contact')
        gender = request.POST.get('gender')
        usertype = request.POST.get('usertype')
        city = request.POST.get('city')
        state = request.POST.get('state')
        qualification = request.POST.get('qualification')
        resume = request.POST.get('resume')
        joindate = request.POST.get('joindate')

        query = Member_Details(fname = fname, mname = mname, lname = lname, email = email,
                               password = password, address = address, contact = contact, gender = gender, usertype = usertype,
                               city=city, state=state, qualification=qualification, resume=resume, joindate=joindate)

        query.save()
        queryset = Member_Details.objects.all().filter(fname = fname)
        return redirect(auth)

    else:
        forms = RegisterForm()
    return redirect(auth)
    #return HttpResponse(render(request, 'profile.html', {'details': queryset}))

def loginuser(request):
    if request.method== 'POST':
        email = request.POST.get('email')
        password = request.POST.get('password')
        query = Member_Details.objects.all().filter(email = email,password = password)
        return HttpResponse(serializers.serialize("json", query), content_type='application/json')

def userprofile(request):
    if request.method== 'POST':
        email = request.POST.get('email')
        password = request.POST.get('password')
        query = Member_Details.objects.all().filter(email = email,password = password)
        if Member_Details.objects.all().filter(email = email, usertype = 'instructor'):
            return HttpResponse(render(request, 'iprofile.html', {'details': query}))
        return HttpResponse(render(request, 'profile.html', {'details': query}))


def usercourse(request):
    queryset = Course_Master.objects.all().filter(Title = 'Python')
    return HttpResponse(render(request, 'courses.html', {'details':queryset}))
def instructorcourse(request):
    return HttpResponse(render(request, 'icourse.html'))





