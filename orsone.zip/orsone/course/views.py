from django.shortcuts import render, redirect
from models import Course_Master
from django.http import HttpResponse
from django.core import serializers
import json
# Create your views here.

def viewcourses(request):
    #img = Course_Master.objects.all().values()
    query = Course_Master.objects.all().filter()
    #return HttpResponse(render(request,'images.html',{"image": img}))
    return HttpResponse(serializers.serialize("json", query), content_type='application/json')

def registercourses(request):
    return render(request, 'course.html')

def addcourses(request):
    if request.method == 'POST':
        title = request.POST.get('title')
        image = request.POST.get('image')
        description = request.POST.get('description')
        status = request.POST.get('status')
        duration = request.POST.get('duration')
        fee = request.POST.get('fee')

        query = Course_Master(Title = title, Image = image, Description = description, Status = status,
                              Duration = duration, Fees = fee)

        query.save()
        return redirect(viewcourses)