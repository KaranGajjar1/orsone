from __future__ import unicode_literals

from django.db import models

from login.models import Member_Details
# Create your models here.
class Course_Master(models.Model):
	course_id = models.IntegerField(primary_key=True,null=False)
	Title = models.CharField(max_length=20,null=False)
	Image = models.ImageField(null=True)
	Description = models.CharField(max_length=100,null=False)
	Status = models.CharField(max_length=10,null=False,choices=(('Active','Active'),('Deactive','Deactive')))
	Duration = models.CharField(max_length=15,null=False)
	Fees = models.IntegerField(null=False)

	def __unicode__(self):
		return str(self.Title)

class Material_Master(models.Model):
	m_id = models.IntegerField(primary_key=True,null=False)
	course_id = models.ForeignKey(Course_Master)
	mname = models.CharField(max_length=20,null=False)
	date = models.DateTimeField()
	files = models.CharField(max_length=100,null=False)

	def __unicode__(self):
		return str(self.mname)

class Instructor_Course(models.Model):
	Instructor_id = models.IntegerField(primary_key=True,null=False)
	course_Id = models.ForeignKey(Course_Master)

	def __unicode__(self):
		return str(self.Instructor_id)

class Member_Course(models.Model):
	Id = models.IntegerField(primary_key=True,null=False)
	course_Id = models.ForeignKey(Course_Master)
	member_id = models.ForeignKey(Member_Details)

	def __unicode__(self):
		return str(self.Id)