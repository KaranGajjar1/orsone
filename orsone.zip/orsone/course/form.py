from django import forms
from course.models import *


class RegisterCourse(forms. ModelForm):
    title = models.CharField(max_length=20)
    image = models.ImageField()
    description = models.CharField(max_length=100)
    status = models.CharField(max_length=10)
    duration = models.CharField(max_length=15)
    fee = models.IntegerField()

    class Meta:
        model = Course_Master
        fields = ('Title','Description','Duration','Fees','Status','Image')