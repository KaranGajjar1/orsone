from django.contrib import admin
from django.contrib import admin

from .models import Course_Master
from .models import Material_Master
from .models import Instructor_Course
from .models import Member_Course
# Register your models here.
admin.site.register(Course_Master)
admin.site.register(Material_Master)
admin.site.register(Instructor_Course)
admin.site.register(Member_Course)
