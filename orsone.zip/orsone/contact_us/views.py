from django.shortcuts import render
from .models import Contact_Us
from django.http import HttpResponse

# Create your views here.
